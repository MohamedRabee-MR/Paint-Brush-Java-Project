import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Shape implements Serializable {
    private String type;
    private Color color;
    private int x1, y1, x2, y2;
    private boolean filled, dotted;
    private List<Point> path; // For Freehand and Eraser
    private int strokeWidth;

    public Shape(String type, Color color, int x, int y, boolean filled, boolean dotted, int strokeWidth) {
        this.type = type;
        this.color = color;
        this.x1 = x;
        this.y1 = y;
        this.x2 = x;
        this.y2 = y;
        this.filled = filled;
        this.dotted = dotted;
        this.path = new ArrayList<>();
        this.path.add(new Point(x, y));
        this.strokeWidth = strokeWidth;
    }
    public int getStrokeWidth() { return strokeWidth; }

    public void updateEndPoint(int x, int y) {
        this.x2 = x;
        this.y2 = y;
        this.path.add(new Point(x, y));
    }

    // Calculation methods for Rect/Oval bounds
    public int getX() { return Math.min(x1, x2); }
    public int getY() { return Math.min(y1, y2); }
    public int getWidth() { return Math.abs(x1 - x2); }
    public int getHeight() { return Math.abs(y1 - y2); }

    public String getType() { return type; }
    public Color getColor() { return color; }
    public boolean isFilled() { return filled; }
    public boolean isDotted() { return dotted; }
    public List<Point> getPath() { return path; }
    public int getX1() { return x1; }
    public int getY1() { return y1; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }
}