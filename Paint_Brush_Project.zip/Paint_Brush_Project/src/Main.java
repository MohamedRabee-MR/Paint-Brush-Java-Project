void main(String[] args) {
    new PaintController();
}