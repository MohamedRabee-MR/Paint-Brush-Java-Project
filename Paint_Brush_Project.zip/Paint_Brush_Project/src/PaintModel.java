import java.awt.Color;
import java.io.*;
import java.util.ArrayList;

public class PaintModel {
    private ArrayList<Shape> shapes = new ArrayList<>();
    private Color currentColor = Color.BLACK;
    private String currentType = "Line";

    public void addShape(Shape s) { shapes.add(s); }
    public ArrayList<Shape> getShapes() { return shapes; }
    public void undo() { if (!shapes.isEmpty()) shapes.remove(shapes.size() - 1); }
    public void clear() { shapes.clear(); }

    public Color getCurrentColor() { return currentColor; }
    public void setCurrentColor(Color c) { this.currentColor = c; }
    public String getCurrentType() { return currentType; }
    public void setCurrentType(String type) { this.currentType = type; }

    public void save(File file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(shapes);
        }
    }

    public void load(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            shapes = (ArrayList<Shape>) ois.readObject();
        }
    }
}