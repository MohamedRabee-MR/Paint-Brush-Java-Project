import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PaintView extends JPanel {
    private PaintModel model;
    // UI Components
    JButton red, green, blue, rect, oval, line, free, eraser, clear, undo, save, load;
    JCheckBox dottedBox, filledBox;
    JSlider thicknessSlider;

    // The dedicated drawing area
    public DrawingCanvas canvas;

    public PaintView(PaintModel model) {
        this.model = model;
        this.setLayout(new BorderLayout());

        // 1. Create the Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        toolbar.setBackground(Color.LIGHT_GRAY);

        // Initialize Components
        red = new JButton("Red"); green = new JButton("Green"); blue = new JButton("Blue");
        rect = new JButton("Rectangle"); oval = new JButton("Oval"); line = new JButton("Line");
        free = new JButton("FreeHand"); eraser = new JButton("Eraser");
        undo = new JButton("Undo"); clear = new JButton("Clear All");
        save = new JButton("Save"); load = new JButton("Open");
        dottedBox = new JCheckBox("Dotted");
        filledBox = new JCheckBox("Filled");
        thicknessSlider = new JSlider(1, 50, 5);

        AbstractButton[] controls = {red, green, blue, rect, oval, line, free, eraser, dottedBox, filledBox, undo, clear, save, load};
        for (AbstractButton b : controls) toolbar.add(b);
        toolbar.add(new JLabel(" Size:"));
        toolbar.add(thicknessSlider);

        // 2. Create the Canvas
        canvas = new DrawingCanvas();

        // 3. Add to Main View
        this.add(toolbar, BorderLayout.NORTH);
        this.add(canvas, BorderLayout.CENTER); // Center fills the remaining space
    }

    // Inner class specifically for drawing to avoid painting over buttons
    public class DrawingCanvas extends JPanel {
        public DrawingCanvas() {
            this.setBackground(Color.WHITE);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); // This now only clears the white canvas area
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            for (Shape s : model.getShapes()) {
                drawShape(g2, s);
            }
        }

        private void drawShape(Graphics2D g2, Shape s) {
            g2.setColor(s.getColor());
            float width = (float) s.getStrokeWidth();

            if (s.isDotted()) {
                float[] dash = {10f, 10f};
                g2.setStroke(new BasicStroke(width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10f, dash, 0f));
            } else {
                g2.setStroke(new BasicStroke(width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            }

            switch (s.getType()) {
                case "Line":
                    g2.drawLine(s.getX1(), s.getY1(), s.getX2(), s.getY2());
                    break;
                case "Rectangle":
                    if (s.isFilled()) g2.fillRect(s.getX(), s.getY(), s.getWidth(), s.getHeight());
                    else g2.drawRect(s.getX(), s.getY(), s.getWidth(), s.getHeight());
                    break;
                case "Oval":
                    if (s.isFilled()) g2.fillOval(s.getX(), s.getY(), s.getWidth(), s.getHeight());
                    else g2.drawOval(s.getX(), s.getY(), s.getWidth(), s.getHeight());
                    break;
                case "FreeHand":
                case "Eraser":
                    if (s.getType().equals("Eraser")) g2.setColor(Color.WHITE);
                    List<Point> path = s.getPath();
                    for (int i = 1; i < path.size(); i++) {
                        g2.drawLine(path.get(i-1).x, path.get(i-1).y, path.get(i).x, path.get(i).y);
                    }
                    break;
            }
        }
    }


}