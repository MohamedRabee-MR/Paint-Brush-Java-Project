import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PaintController extends JFrame {
    private PaintModel model;
    private PaintView view;
    private Shape currentShape;

    public PaintController() {
        model = new PaintModel();
        view = new PaintView(model);


        // Interaction Listeners
        view.canvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int currentThickness = view.thicknessSlider.getValue();

                currentShape = new Shape(
                        model.getCurrentType(),
                        model.getCurrentColor(),
                        e.getX(), e.getY(),
                        view.filledBox.isSelected(),
                        view.dottedBox.isSelected(),
                        currentThickness // Pass the thickness here
                );
                model.addShape(currentShape);
                view.repaint();
            }
        });

        view.canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (currentShape != null) {
                    currentShape.updateEndPoint(e.getX(), e.getY());
                    view.repaint();
                }
            }
        });

        // Button Listeners
        view.red.addActionListener(e -> model.setCurrentColor(Color.RED));
        view.green.addActionListener(e -> model.setCurrentColor(Color.GREEN));
        view.blue.addActionListener(e -> model.setCurrentColor(Color.BLUE));

        view.rect.addActionListener(e -> model.setCurrentType("Rectangle"));
        view.oval.addActionListener(e -> model.setCurrentType("Oval"));
        view.line.addActionListener(e -> model.setCurrentType("Line"));
        view.free.addActionListener(e -> model.setCurrentType("FreeHand"));
        view.eraser.addActionListener(e -> model.setCurrentType("Eraser"));

        view.undo.addActionListener(e -> { model.undo(); view.repaint(); });
        view.clear.addActionListener(e -> { model.clear(); view.repaint(); });

        view.save.addActionListener(e -> handleSave());
        view.load.addActionListener(e -> handleLoad());

        this.add(view);
        this.setTitle("Paint Brush v1.0");
        this.setSize(1300, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void handleSave() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try { model.save(chooser.getSelectedFile()); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, "Save Failed"); }
        }
    }

    private void handleLoad() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try { model.load(chooser.getSelectedFile()); view.repaint(); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, "Load Failed"); }
        }
    }

    public static void main(String[] args) {
        new PaintController();
    }
}